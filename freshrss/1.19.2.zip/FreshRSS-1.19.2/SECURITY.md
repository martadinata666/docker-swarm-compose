# Security Policy

## Reporting a Vulnerability

Please report security issues to alexandre@alapetite.fr
