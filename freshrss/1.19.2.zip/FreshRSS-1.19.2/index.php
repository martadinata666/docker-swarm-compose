<?php
header('Location: p/', true, 301);
include('index.html');
