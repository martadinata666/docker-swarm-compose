# Changing the source code

## Accessing the database

> **TODO**

## Writing an action and its related view

> **TODO**

## Authentication

> **TODO**

## Logs

> **TODO**
