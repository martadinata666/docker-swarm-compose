# Minz

Minz is the homemade PHP framework used by FreshRSS.

The documentation is still incomplete and it would be great to explain:

- routing, controllers and actions
- configuration
- models and database
- views
- URLs management
- sessions
- internationalisation
- extensions
- mailer

Existing documentation includes:

- [How to manage migrations](migrations.md)
