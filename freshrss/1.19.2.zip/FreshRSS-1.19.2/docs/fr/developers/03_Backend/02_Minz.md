# Minz

## Modèles

> **À FAIRE**

## Contrôleurs et actions

> **À FAIRE**

## Vues

> **À FAIRE**

## Routage

> **À FAIRE**

## Écriture des URL

> **À FAIRE**

## Internationalisation

> **À FAIRE**

## Comprendres les mécanismes internes

> **À FAIRE**
