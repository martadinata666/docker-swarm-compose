# Les vues

## Les fichiers .phtml

> **À FAIRE**

## Écrire une URL

> **À FAIRE**

## Afficher une icône

> **À FAIRE**

## Internationalisation

> **À FAIRE**
