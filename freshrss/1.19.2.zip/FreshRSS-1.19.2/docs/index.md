# Welcome to the FreshRSS documentation

If you want to contribute, you can [find us on GitHub](https://github.com/FreshRSS/FreshRSS).

- [English documentation](./en/index.md)
- [Documentation française](./fr/index.md)
