#!/bin/sh
sass --watch ansum.scss:ansum.css
