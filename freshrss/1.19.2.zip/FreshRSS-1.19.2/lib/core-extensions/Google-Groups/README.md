# Google Groups

Needed for discovering RSS feeds from [Google Groups](https://groups.google.com).
