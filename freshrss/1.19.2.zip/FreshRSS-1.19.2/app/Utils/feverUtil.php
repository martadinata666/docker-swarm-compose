<?php

class FreshRSS_fever_Util {
	const FEVER_PATH = DATA_PATH . '/fever';

	/**
	 * Make sure the fever path exists and is writable.
	 *
	 * @return boolean true if the path is writable, else false.
	 */
	public static function checkFeverPath() {
		if (!file_exists(self::FEVER_PATH)) {
			@mkdir(self::FEVER_PATH, 0770, true);
		}

		$ok = is_writable(self::FEVER_PATH);
		if (!$ok) {
			Minz_Log::error("Could not save Fever API credentials. The directory does not have write access.");
		}
		return $ok;
	}

	/**
	 * Return the corresponding path for a fever key.
	 *
	 * @param string $feverKey
	 * @return string
	 */
	public static function getKeyPath($feverKey) {
		$salt = sha1(FreshRSS_Context::$system_conf->salt);
		return self::FEVER_PATH . '/.key-' . $salt . '-' . $feverKey . '.txt';
	}

	/**
	 * Update the fever key of a user.
	 *
	 * @param string $username
	 * @param string $passwordPlain
	 * @return string|false the Fever key, or false if the update failed
	 */
	public static function updateKey($username, $passwordPlain) {
		$ok = self::checkFeverPath();
		if (!$ok) {
			return false;
		}

		self::deleteKey($username);

		$feverKey = strtolower(md5("{$username}:{$passwordPlain}"));
		$feverKeyPath = self::getKeyPath($feverKey);
		$res = file_put_contents($feverKeyPath, $username);
		if ($res !== false) {
			return $feverKey;
		} else {
			Minz_Log::warning('Could not save Fever API credentials. Unknown error.', ADMIN_LOG);
			return false;
		}
	}

	/**
	 * Delete the Fever key of a user.
	 *
	 * @param string $username
	 * @return boolean true if the deletion succeeded, else false.
	 */
	public static function deleteKey($username) {
		$userConfig = get_user_configuration($username);
		if ($userConfig === null) {
			return false;
		}

		$feverKey = $userConfig->feverKey;
		if (!ctype_xdigit($feverKey)) {
			return false;
		}

		$feverKeyPath = self::getKeyPath($feverKey);
		return @unlink($feverKeyPath);
	}
}
