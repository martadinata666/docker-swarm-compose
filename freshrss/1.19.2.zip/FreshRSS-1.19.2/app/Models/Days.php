<?php

class FreshRSS_Days {
	const TODAY = 0;
	const YESTERDAY = 1;
	const BEFORE_YESTERDAY = 2;
}
