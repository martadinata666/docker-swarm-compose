<?php

class FreshRSS_ActionController extends Minz_ActionController {

	/**
	 * @var FreshRSS_View
	 */
	protected $view;
}
