<?php

class FreshRSS_DAO_Exception extends Exception {

}
