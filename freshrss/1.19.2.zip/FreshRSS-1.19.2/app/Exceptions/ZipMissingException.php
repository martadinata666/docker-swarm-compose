<?php

class FreshRSS_ZipMissing_Exception extends Exception {
}
