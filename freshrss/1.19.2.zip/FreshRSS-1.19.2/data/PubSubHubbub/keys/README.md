List of keys given to PubSubHubbub hubs

* ./sha1(random + salt).txt
	* base64url(canonicalUrl)
